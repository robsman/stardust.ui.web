/*******************************************************************************
 * Copyright (c) 2011 SunGard CSA LLC and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: SunGard CSA LLC - initial API and implementation and/or initial
 * documentation
 ******************************************************************************/

define(
		[],
		function() {

			bpm = {
				interaction : new Interaction()
			};

			return {
				bpm : bpm
			};

			/**
			 * 
			 */
			function Interaction() {
				this.url = null;
				this.callbackUrl = null;
				this.metadata = null;
				this.input = null;
				this.output = {};

				/**
				 * 
				 */
				Interaction.prototype.bind = function() {
					this.url = window.location;

					// Extract callback URL

					console.log("Binding Interaction Object from URL: "
							+ this.url);

					this.callbackUrl = jQuery.url(window.location.search)
							.param("ippPortalBaseUri");

					console.log("Retrieve metadata and input from URL: "
							+ this.callbackUrl);

					// Get metadata

					this.metadata = {}

					// Get input

					var deferred = jQuery.Deferred();
					var interaction = this;
					
					jQuery.ajax({
						type : "GET",
						url : this.callbackUrl + "/interaction",
						contentType : "application/json"
					}).done(function(data) {
						console.log("Retrieved input data");
						console.log(data);

						interaction.input = data.input;
						
						deferred.resolve();
					}).fail(function() {
						console.log("Error retrieving input data");

						interaction.input = {};

						deferred.reject();
					});

					return deferred.promise();
				};

				/**
				 * 
				 */
				Interaction.prototype.get = function() {
					jQuery
							.ajax({
								type : "GET",
								url : options.url,
								callbackScope : options.callbackScope,
								async : false,
								success : callbacks.hasOwnProperty('success') ? callbacks.success
										: null,
								error : callbacks.hasOwnProperty('error') ? callbacks.error
										: null
							});
				};

				/**
				 * 
				 */
				Interaction.prototype.post = function() {
					jQuery
							.ajax({
								type : "POST",
								url : this.callbackUrl + "/interaction",
								contentType : "application/json",
								data : JSON.stringify({output: this.output}),
							});
				};

				/**
				 * Submit the current state of the Output object to the
				 * interaction object.
				 */
				Interaction.prototype.submit = function(status) {
					console.debug("Submit output data");
					console.debug(this.output);
					this.post();
				};

				/**
				 * 
				 */
				Interaction.prototype.complete = function(status) {
					console.log("Complete activity with output data:");
					console.log(this.output);
					this.post();
				};
			}
		});