function loanRequestController($scope) {
	console.log("Start controller");
	
	$scope.customer = {
			firstName : "Heinz",
			lastName : "Schenk"
		};

	$scope.loanRequest = {
			amount : 1000,
			duration : 10
		};
}