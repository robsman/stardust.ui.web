/*******************************************************************************
 * Copyright (c) 2011 SunGard CSA LLC and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: SunGard CSA LLC - initial API and implementation and/or initial
 * documentation
 ******************************************************************************/

define([], function() {
	return {
		retrieveCustomer : retrieveCustomer,
		calculateLoanPlan : calculateLoanPlan
	};

	/**
	 * Simulates server REST call to retrieve customer data
	 */
	function retrieveCustomer(id) {
		var deferred = jQuery.Deferred();

		var customer;

		if (id == 4711) {
			customer = {
				firstName : "Lara",
				lastName : "Croft",
				address : {
					street : "Tombstone Alley",
					city : "Croft Mansion",
					postalCode : "6789090",
					country : "UK"
				}
			};
		} else {
			customer = {
				firstName : "Jaco",
				lastName : "Pastorius",
				address : {
					street : "B Flat Street",
					city : "Teen Town",
					postalCode : "1625",
					country : "USA"
				}
			};
		}

		deferred.resolve(customer);

		return deferred.promise();
	}

	/**
	 * Simulates server REST call to retrieve calculate a loan plan
	 */
	function calculateLoanPlan(amount, interestBinding, maximumMonthlyPayment) {
		var deferred = jQuery.Deferred();

		var loanPlan = {
			amount : amount,
			monthlyPayment : 0.9 * maximumMonthlyPayment,
			interestBinding : interestBinding,
			effectiveInterest : 2.5
		};

		deferred.resolve(loanPlan);

		return deferred.promise();
	}
});