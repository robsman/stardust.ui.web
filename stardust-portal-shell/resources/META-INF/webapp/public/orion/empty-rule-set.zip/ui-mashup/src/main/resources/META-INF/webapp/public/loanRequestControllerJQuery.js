/*******************************************************************************
 * Copyright (c) 2011 SunGard CSA LLC and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: SunGard CSA LLC - initial API and implementation and/or initial
 * documentation
 ******************************************************************************/

define(
		[ "ui-mashup/public/serviceAdapter" ],
		function(serviceAdapter) {
			return {
				create : function() {
					var controller = new LoanRequestControllerJQuery();

					controller.initialize();

					return controller;
				}
			};

			/**
			 * JS Controller for Loan Request Panel. Independent of IPP
			 * interaction.
			 */
			function LoanRequestControllerJQuery() {
				/**
				 * 
				 */
				LoanRequestControllerJQuery.prototype.initialize = function() {
					this.firstNameInput = jQuery("#firstNameInput");
					this.amountInput = jQuery("#amountInput");
					this.interestBindingInput = jQuery("#interestBindingInput");
					this.maximumMonthlyPaymentInput = jQuery("#maximumMonthlyPaymentInput");
					this.monthlyPaymentOutput = jQuery("#monthlyPaymentOutput");
					this.effectiveInterestOutput = jQuery("#effectiveInterestOutput");
					this.submitButton = jQuery("#submitButton");
					this.calculateLoanPlanLink = jQuery("#calculateLoanPlanLink");
					this.loanPlan = null;

					this.calculateLoanPlanLink.click({
						controller : this
					}, function(event) {
						event.data.controller.calculateLoanPlan();
					})
				};

				/**
				 * 
				 */
				LoanRequestControllerJQuery.prototype.initializeFromCustomerId = function(customerId) {
					var deferred = jQuery.Deferred();
					var controller = this;

					serviceAdapter.retrieveCustomer(customerId).done(function(customer){
						controller.setCustomer(customer);

						deferred.resolve(customer);
					}).fail(function(){				
						deferred.reject();
					});			

					return deferred.promise();
				};

				/**
				 * 
				 */
				LoanRequestControllerJQuery.prototype.setCustomer = function(
						customer) {
					jQuery("#firstNameInput").val(customer.firstName);
					jQuery("#lastNameInput").val(customer.lastName);
					// jQuery("#dateOfBirthInput").val(bpm.interaction.input.New_0.dateOfBirth);

					if (customer.address) {
						jQuery("#streetInput").val(customer.address.street);
						jQuery("#cityInput").val(customer.address.city);
						jQuery("#postalCodeInput").val(
								customer.address.postalCode);
						jQuery("#countrySelect").val(customer.address.country);
					}
				};

				/**
				 * 
				 */
				LoanRequestControllerJQuery.prototype.calculateLoanPlan = function() {
					var controller = this;
					serviceAdapter.calculateLoanPlan(this.amountInput.val(),
							this.interestBindingInput.val(),
							this.maximumMonthlyPaymentInput.val()).done(
							function(loanPlan) {
								controller.loanPlan = loanPlan;
								controller.monthlyPaymentOutput
										.text(loanPlan.monthlyPayment);
								controller.effectiveInterestOutput
										.text(loanPlan.effectiveInterest);
							}).fail();
				}
			}
		});