/*******************************************************************************
 * Copyright (c) 2011 SunGard CSA LLC and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors: SunGard CSA LLC - initial API and implementation and/or initial
 * documentation
 ******************************************************************************/

/**
 * @author Marc Gille
 */

var bpm = null;
	
require.config({
	baseUrl: "../../",
	paths : {
		'jquery' : ['bpm-modeler/js/libs/jquery/jquery-1.7.2', '//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min'],
		'jquery.url': ['bpm-modeler/js/libs/jquery/plugins/jquery.url', 'https://raw.github.com/allmarkedup/jQuery-URL-Parser/4f5254f2519111ad7037d398b2efa61d3cda58d4/jquery.url']
	},
	shim: {
		'jquery.url': ['jquery']
	}
});

require(["require",
         "jquery",
         "jquery.url",
         "ui-mashup/public/interaction"
], function(require) {
	jQuery(document).ready(function() {
		require("ui-mashup/public/interaction").bpm.interaction.bind().done(function() {
			console.log("Bound Interaction object.");
			
			// Additional instrumentation for interaction with IPP
			
			jQuery("#firstNameInput").val(bpm.interaction.input.New_0.firstName);
			jQuery("#lastNameInput").val(bpm.interaction.input.New_0.lastName);
			jQuery("#dateOfBirthInput").val(bpm.interaction.input.New_0.dateOfBirth);
			jQuery("#amountInput").change(function(event){
				bpm.interaction.output.loanRequest = {amount: jQuery(this).val()};
				bpm.interaction.submit();
			});
			jQuery("#submitButton").click(function(){
				bpm.interaction.output.loanRequest = {amount: jQuery("#amountInput").val()};
				bpm.interaction.complete();
			});
		}).fail(function() {
			console.log("Failed to bind Interaction object.");
		});
	});
});

